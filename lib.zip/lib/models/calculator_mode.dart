// lib/models/calculator_mode.dart

enum CalculatorMode { basic, scientific, programmer }

enum AngleMode { degrees, radians }

enum ProgrammerBase { bin, oct, dec, hex }
