import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/history_provider.dart';
import '../providers/calculator_provider.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final history = context.watch<HistoryProvider>();
    final calc = context.read<CalculatorProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok =
                  await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Clear all history?'),
                      content: const Text('This action cannot be undone.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: const Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: const Text('Clear'),
                        ),
                      ],
                    ),
                  ) ??
                  false;
              if (ok) {
                await history.clear();
              }
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: history.items.length,
        itemBuilder: (context, index) {
          final item = history.items.reversed.toList()[index];
          return ListTile(
            title: Text(item.expression),
            subtitle: Text(item.result),
            onTap: () {
              calc.addToExpression(item.result);
              Navigator.pop(context);
            },
          );
        },
      ),
    );
  }
}
